var searchData=
[
  ['previsualizahtml_2epy_0',['previsualizaHTML.py',['../previsualiza_h_t_m_l_8py.html',1,'']]],
  ['procesarcsv_2epy_1',['procesarcsv.py',['../procesarcsv_8py.html',1,'']]]
];
