var searchData=
[
  ['procesar_5farchivo_5fcsv_0',['procesar_archivo_csv',['../namespaceprocesarcsv.html#a7e3b46c822d3408e8ddae4128a726e67',1,'procesarcsv']]],
  ['procesar_5fkeyword_1',['procesar_keyword',['../namespacewrite_s_e_o.html#a98e10db0a0f831fc9a80fef2844000a8',1,'writeSEO']]]
];
