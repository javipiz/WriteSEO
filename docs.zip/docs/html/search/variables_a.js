var searchData=
[
  ['openai_0',['openai',['../namespacewrite_s_e_o.html#aadefcde9ce594fc5a5465f822923163f',1,'writeSEO']]]
];
