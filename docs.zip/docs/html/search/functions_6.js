var searchData=
[
  ['obtenervalueserp_0',['obtenerValueSERP',['../namespacewrite_s_e_o.html#ac262ee138e9e0f6f8251987adee821ca',1,'writeSEO']]]
];
